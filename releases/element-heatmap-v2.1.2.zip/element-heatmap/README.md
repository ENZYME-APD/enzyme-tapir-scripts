# Element heatmap for Archicad (v2.1.2)

Colour elements in Archicad by any property, using the Tapir add-on.

## Run

    python3 element_heatmap_panel.py

1. Elements: whole model or current selection, filtered by type, layer and
   classification (linked lists with element counts). Press Find elements.
2. Property: search and pick one.
3. Colours: pick a style and press Show heatmap. "Legend window" opens a
   separate legend. "Clear" removes the highlight.

Command line:

    python3 element_heatmap.py --type Column --list-properties
    python3 element_heatmap.py --type Column --property "Column/Core Width" --style Magma
    python3 element_heatmap.py --clear
    python3 clear_highlight.py

## Requirements

- Archicad with the Tapir Add-On (tested on Archicad 30, Tapir 1.7.3)
- Python 3 with tkinter (python.org Python includes it; Homebrew: brew install python-tk)
- No other packages

Values are in Archicad base units (m, m², m³, rad).

Source: https://github.com/ENZYME-APD/enzyme-tapir-scripts  ·  MIT licence
